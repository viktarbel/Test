<?php
/**
 * @deprecated 6.3.0
 */
namespace Tribe\Admin\Notice\Marketing;

_deprecated_file( __FILE__, '6.3.0', 'No Replacement' );

/**
 * Class End_Of_Year_Sale
 *
 * @since 4.14.9
 * @deprecated 6.3.0
 *
 * @package Tribe\Admin\Notice\Marketing
 */
class End_Of_Year_Sale {
	public function __call( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}

	public static function __callStatic( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}
}
